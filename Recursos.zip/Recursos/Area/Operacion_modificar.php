<?php

include("Conexion.php");

$id=$_REQUEST['Id'];
$nombre=$_POST['Nombre'];

$query="UPDATE areas SET Nombre='$nombre' WHERE Id='$id'";

$resultado= $conexion->query($query);

if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Inserción no exitosa";
}

?>