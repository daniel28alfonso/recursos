
<?php

include("Conexion.php");



$nombre=$_POST['Nombre'];
$query="INSERT INTO areas( Nombre) VALUES('$nombre')";

$resultado= $conexion->query($query);

if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Insercion no exitosa";
}

?>