
<?php

include("Conexion.php");



$nombre=$_POST['Nombre'];
$apellido=$_POST['Apellido'];
$correo=$_POST['Correo'];
$usuario=$_POST['usuario'];
$password=$_POST['Password'];

$query="INSERT INTO registros(Nombre,Apellidos,Correo,Nom_usuario,Password) VALUES('$nombre','$apellido','$correo','$usuario','$password')";

$resultado= $conexion->query($query);

if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Insercion no exitosa";
}

?>