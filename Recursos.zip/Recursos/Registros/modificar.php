<html>
<head>
<meta charset="UTF-8" />
	<title></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>Parcial 1</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../../Vista/estilos.css">
	<title>Modificar</title>

</head>
<body>
	<center>
<div id="contenido">
		<?php
		include("Conexion.php");

		$id=$_REQUEST['Id'];

		$query="SELECT * FROM registros WHERE Id='$id'";
		$resultado=$conexion->query($query);
		$row=$resultado->fetch_assoc();

?>
<h1> Modificar datos del registros de usarios </h1>
<form action="Operacion_modificar.php?Id=<?php echo $row['Id']; ?>" method="POST">

	</br></br>
	<input type="text" REQUIRED name="Nombre" placeholder="Nombre"value="<?php echo $row['Nombre']; ?>" /> </br></br>
	<input type="text" REQUIRED name="Apellido" placeholder="Apellido"value="<?php echo $row['Apellidos']; ?>" /> </br></br>
	<input type="text" REQUIRED name="Correo" placeholder="Correo"value="<?php echo $row['Correo']; ?>" /> </br></br>
	<input type="text" REQUIRED name="usuario" placeholder="usuario"value="<?php echo $row['Nom_usuario']; ?>" /> </br></br>
    <input type="password" REQUIRED name="Password" placeholder="Password"value="<?php echo $row['Password']; ?>" /> </br></br>
	<input type="submit" value="Aceptar" />

</form>
</div>
</center>
</body>
</html>
