<?php

include("Conexion.php");
$id=$_REQUEST['Id'];
$nombre=$_POST['Nombre'];
$apellido=$_POST['Apellido'];
$correo=$_POST['Correo'];
$usuario=$_POST['usuario'];
$password=$_POST['Password'];

$query="UPDATE registros SET Nombre='$nombre', Apellidos='$apellido',Correo='$correo',Nom_usuario='$usuario',Password='$password' WHERE Id='$id'";

$resultado= $conexion->query($query);

if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Inserción no exitosa";
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

?>