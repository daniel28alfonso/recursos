<!DOCTYPE html>
<html>
<head>

   <title>Guardar</title>

</head>

<head>
	
<meta charset="UTF-8" />
	<title></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>PROYECTO</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	   <link rel="stylesheet" href="../estiloform.css">
   <title>Tabla</title>
</head>

<body>


     
 <div id="container">
  <h1>&bull; REGISTRO USUARIOS&bull;</h1>
  <div class="underline">
  </div>

 
  <form action="Operacion_guardar.php" method="post" id="contact_form">

    <div class="name">
      <label for="name"></label>
      <input type="text" REQUIRED name="Nombre" placeholder="Nombre..." value="" required>
    </div>
      <div class="email">
      <label for="email"></label>
      <input type="text" REQUIRED name="Apellido" placeholder="Apellidos de usuario..." value="" required>
    </div>
      <div class="email">
      <label for="email"></label>
      <input type="text" REQUIRED name="Correo" placeholder="Correo..." value="" required>
    </div>
    <div class="name">
      <label for="name"></label>
      <input type="text" REQUIRED name="usuario" placeholder="Nombre de usuario..." value="" required>
    </div>
      <div class="email">
      <label for="email"></label>
      <input type="password" REQUIRED name="Password" placeholder="# Clave..." value=""required>
    </div>
    <div class="submit">
      <input type="submit" value="REGISTRAR" id="form_button" />
    </div>
</form>
	 <form action="../../Recursos/index.html" method="post" id="contact_form">

	      <div class="submit"><input type="submit" value="INICIO" id="form_button" />
               </div>
              </form>
     
      <form action="tabla.php" method="post" id="contact_form">

	      <div class="submit"><input type="submit" value="VER TABLA DE REGISTROS DE ASPIRANTES" id="form_button" />
               </div>
              </form>
     
	
</body>
</html>

