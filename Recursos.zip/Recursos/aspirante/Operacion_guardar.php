
<?php

include("Conexion.php");



$cedula=$_POST['Id'];
$nombre=$_POST['Nombre'];
$apellido=$_POST['Apellido'];
$edad=$_POST['Edad'];
$direccion=$_POST['Direccion'];
$telefono=$_POST['Telefono'];
$profesion=$_POST['Profesion'];
$cargo=$_POST['Cod_cargo'];
$correo=$_POST['Correo'];
$ciudad=$_POST['Ciudad'];
$estado=$_POST['Cod_estado_civil'];
$contratado=$_POST['Cod_contratado'];
$entrevista=$_POST['Cod_entrevista'];

$query="INSERT INTO aspirante(Id,Nombre,Apellido,Edad,Direccion,Telefono,Profesion,Cargo,Correo,Ciudad,Cod_estado_civil,Cod_contratado,Cod_entrevista) VALUES ('$cedula','$nombre','$apellido','$edad','$direccion','$telefono','$profesion','$cargo','$correo','$ciudad','$estado','$contratado','$entrevista')";


$resultado= $conexion->query($query);


if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Insercion no exitosa";
}

?>