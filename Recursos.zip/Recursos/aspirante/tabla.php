<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<title></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="estilotablaprob.css">
	<title>Tabla</title>


</head>



<header>
<center>
	<nav class="menu">
		
		<ul>
			<a href="../../Recursos/index.html">INICIO</a>
			<a href="../Registros/formulario.php">VOLVER</a>
			
		</ul> 
	</ul>
</nav>
</center>
</header>



<body>

    <center></br></br></br>
		<table bgcolor="#BDC3C7 " border="1">
			<thead>
				<tr>
					<th colspan="1"><a href="formulario.php">Nuevo</a></th>
					<th colspan="5">Lista de Usuarios</th>
				</tr>
			</thead>

			<tbody>
				<tr>
					<td>Id</td>
					<td>Nombre</td>
                    <td>Apellidos</td>
					<td>Edad</td>
					<td>Direccion</td>
					<td>Telefeno</td>
                    <td>Profesion</td>
                    <td>Cod_cargo_aspira</td>
					<td>Correo</td>
                    <td>Ciudad</td>
                    <td>Estado civil</td>
					<td>Contratad@</td>
                    <td>Cod_entrevista</td>
					<td colspan="2">Operaciones</td>
				      </tr>


										       <?php
												include("Conexion.php");

												$query="SELECT * FROM aspirante";
												$resultado=$conexion->query($query);
												while($row=$resultado->fetch_assoc()){
													?>
													<tr>
														<td><?php echo $row['Id']; ?></td>
														<td><?php echo $row['Nombre']; ?></td>
														<td><?php echo $row['Apellido']; ?></td>
														<td><?php echo $row['Edad']; ?></td>
														<td><?php echo $row['Direccion']; ?></td>
                                                        <td><?php echo $row['Telefono']; ?></td>
                                                        <td><?php echo $row['Profesion']; ?></td>
														<td><?php echo $row['Cargo']; ?></td>
														<td><?php echo $row['Correo']; ?></td>
														<td><?php echo $row['Ciudad']; ?></td>
														<td><?php echo $row['Cod_estado_civil']; ?></td>
                                                        <td><?php echo $row['Cod_contratado']; ?></td>
                                                        <td><?php echo $row['Cod_entrevista']; ?></td>
                                                    
														<td><a href="modificar.php?Id=<?php echo $row['Id']; ?>">Modificar</a></td>
														<td><a href="eliminar.php?Id=<?php echo $row['Id']; ?>">Eliminar</a></td>
													</tr>
													<?php
												}
												?>

											</tbody>
										</table>
									</center>
								</body>
								</html>