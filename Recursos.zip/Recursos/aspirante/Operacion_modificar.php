<?php

include("Conexion.php");
$cedula=$_REQUEST['Id'];
$nombre=$_POST['Nombre'];
$apellido=$_POST['Apellido'];
$edad=$_POST['Edad'];
$direccion=$_POST['Direccion'];
$telefono=$_POST['Telefono'];
$profesion=$_POST['Profesion'];
$cargo=$_POST['cargo'];
$correo=$_POST['Correo'];
$ciudad=$_POST['Ciudad'];
$estado=$_POST['Cod_estado_civil'];
$contratado=$_POST['Cod_contratado'];
$entrevista=$_POST['Cod_entrevista'];
$query="UPDATE aspirante SET Nombre='$nombre',Apellido='$apellido',Edad='$edad',Direccion='$direccion',Telefono='$telefono',Cargo='$cargo',Correo='$correo',Ciudad='$ciudad',Cod_estado_civil='$estado',Cod_contratado='$contratado',Cod_entrevista='$entrevista'  WHERE Id='$cedula'";

$resultado= $conexion->query($query);

if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Inserción no exitosa";
    
}

?>