<?php

include("Conexion.php");
$cedula=$_REQUEST['Id'];
$nombre=$_POST['Nombre'];
$apellido=$_POST['Apellido'];
$direccion=$_POST['Direccion'];
$telefono=$_POST['Telefono'];
$profesion=$_POST['Profesion'];
$cargo=$_POST['Cod_cargo'];
$estado=$_POST['Cod_estado_civil'];
$area=$_POST['Cod_area'];
$salario=$_POST['Salario'];
$correo=$_POST['Correo'];
$ciudad=$_POST['Ciudad'];
//$Fecha=$_POST['Fechas'];
$historia=$_POST['Cod_historia'];


$query="UPDATE empleados SET Nombre='$nombre',Apellido='$apellido',Direccion='$direccion',Telefono='$telefono',Profesion='$profesion',Cod_cargo=$cargo,Cod_estado_civil='$estado',Cod_area='$area',Salario='$salario',Correo='$correo',Ciudad='$ciudad',Cod_historia=='$historia' WHERE Id='$cedula'";

$resultado= $conexion->query($query);

if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Inserción no exitosa";
    
}

?>