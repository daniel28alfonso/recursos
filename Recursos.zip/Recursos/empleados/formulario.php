<?php
include("Conexion.php");
//traer datos de la tabla areas
$consulta = "select * from areas";
$res = mysqli_query($conexion,$consulta)or die(mysqli_error($conexion));
$cant = mysqli_num_rows($res);
//traer datos de la tabla cargos
$consul = "select * from cargos";
$resp = mysqli_query($conexion,$consul)or die(mysqli_error($conexion));
$canti = mysqli_num_rows($resp);
//traer datos de la tabla areas
$c = "select * from estado_civl";
$r = mysqli_query($conexion,$c)or die(mysqli_error($conexion));
$c = mysqli_num_rows($r);
//traer datos de la tablas historias empleados
$co = "select * from historias_emp";
$re = mysqli_query($conexion,$co)or die(mysqli_error($conexion));
$cu = mysqli_num_rows($re);
?>

<!DOCTYPE html>
<html>
<head>

   <title>Guardar</title>

</head>

<head>
	
<meta charset="UTF-8" />
	<title></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>PROYECTO</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	   <link rel="stylesheet" href="../estiloform.css">
   <title>Tabla</title>
</head>

<body>

     
 <div id="container">
  <h1>&bull; REGISTRO EMPLEADOS&bull;</h1>
  <div class="underline">
  </div>

 
  <form action="Operacion_guardar.php" method="post" id="contact_form">
      <div class="name">
      <label for="name"></label>
      <input type="text" REQUIRED name="Id" placeholder="Cedula..." value="" required>
    </div>

    <div class="email">
      <label for="email"></label>
      <input type="text" REQUIRED name="Nombre" placeholder="Nombre..." value="" required>
    </div>
      <div class="name">
      <label for="name"></label>
      <input type="text" REQUIRED name="Apellido" placeholder="Apellido..." value="" required>
    </div>
      <div class="email">
      <label for="email"></label>
      <input type="text" REQUIRED name="Direccion" placeholder="Direccion..." value=""required>
    </div>
      <div class="name">
      <label for="name"></label>
      <input type="text" REQUIRED name="Telefono" placeholder="Telefono..." value="" required>
    </div>
      <div class="email">
      <label for="email"></label>
      <input type="text" REQUIRED name="Profesion" placeholder="Profesion..." value=""required>
    </div>
      <div class="name">
      <label for="name"></label>
      <input type="text" REQUIRED name="Cod_cargo" placeholder="Cargo..." value="" required>
    </div>
    <div class="name">
    <label> <select name="" >
      <?php foreach ($resp as $opciones):?>
      <option value="<?php echo $opciones['Id'],$opciones['Nombre']?>"><?php echo $opciones['Id'],$opciones['Nombre']?></option>
          
    <?php endforeach ?> 
    </select>
    </label>
      </div>
      <div class="name">
      <label for="name"></label>
      <input type="text" REQUIRED name="Cod_estado_civil" placeholder="Estado civil..." value=""required>
      </div>
      <div class="name">
    <label> <select name="" >
      <?php foreach ($r as $opciones):?>
      <option value="<?php echo $opciones['Id'],$opciones['Estado']?>"><?php echo $opciones['Id'],$opciones['Estado']?></option>    
      <?php endforeach ?> 
    </select>
    </label>
      </div>
    <div class="name">
    <label for="name"></label>
    <input type="text" REQUIRED name="Cod_area" placeholder="Area..." value="" required>
    </div>
    <div class="name">
    <label> <select name="" >
      <?php foreach ($res as $opciones):?>
      <option value="<?php echo $opciones['Id'],$opciones['Nombre']?>"><?php echo $opciones['Id'],$opciones['Nombre']?></option>
          
    <?php endforeach ?> 
    </select>
    </label>
      </div>


      
      
     <div class="name">
      <label for="name"></label>
      <input type="text" REQUIRED name="Salario" placeholder="Salario..." value=""required>
    </div>
      <div class="email">
      <label for="email"></label>
      <input type="text" REQUIRED name="Correo" placeholder="Correo..." value="" required>
    </div>
      <div class="name">
      <label for="name"></label>
      <input type="text" REQUIRED name="Ciudad" placeholder="Ciudad..." value="" required>
    </div>
      <div class="email">
      <label for="email"></label>
      <input type="text" REQUIRED name="Cod_historia" placeholder="Codigo historia..." value="" required>
    </div>
      <div class="name">
    <label> <select name="" >
      <?php foreach ($re as $opciones):?>
      <option value="<?php echo $opciones['Id'],$opciones['Cod_emp']?>"><?php echo $opciones['Id'],$opciones['Cod_emp']?></option>
          
    <?php endforeach ?> 
    </select>
    </label>
      </div>
      
    <div class="submit">
      <input type="submit" value="REGISTRAR" id="form_button" />
    </div>

</form>
     <form action="../../Recursos/index.html" method="post" id="contact_form">

	      <div class="submit"><input type="submit" value="INICIO" id="form_button" />
               </div>
              </form>
     
      <form action="tabla.php" method="post" id="contact_form">

	      <div class="submit"><input type="submit" value="VER TABLA DE REGISTROS DE EMPLEADOS" id="form_button" />
               </div>
              </form>
     
    
	
</body>
</html>

