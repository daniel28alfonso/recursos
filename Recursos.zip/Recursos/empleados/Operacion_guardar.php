
<?php

include("Conexion.php");



$cedula=$_POST['Id'];
$nombre=$_POST['Nombre'];
$apellido=$_POST['Apellido'];
$direccion=$_POST['Direccion'];
$telefono=$_POST['Telefono'];
$profesion=$_POST['Profesion'];
$cargo=$_POST['Cod_cargo'];
$estado=$_POST['Cod_estado_civil'];
$area=$_POST['Cod_area'];
$salario=$_POST['Salario'];
$correo=$_POST['Correo'];
$ciudad=$_POST['Ciudad'];
//$Fecha=$_POST['Fechas'];
$historia=$_POST['Cod_historia'];

$query="INSERT INTO empleados(id,Nombre,Apellidos,Direccion,Telefono,Profesion,Cod_cargo,Cod_estado_civil,Cod_area,Salario,Correo,Ciudad,Cod_historia) VALUES ('$cedula','$nombre','$apellido','$direccion','$telefono','$profesion','$cargo','$estado','$area','$salario','$correo','$ciudad','$historia')";


$resultado= $conexion->query($query);


if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Insercion no exitosa";
}

?>