<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<title></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<title>Tabla</title>


</head>



<header>
<center>
	<nav class="menu">
		
		<ul>
			<a href="../../Recursos/index.html">INICIO</a>
			<a href="../empleados/formulario.php">VOLVER</a>
			
		</ul> 
	</ul>
</nav>
</center>
</header>



<body>

    <center></br></br></br>
		<table bgcolor="#BDC3C7 " border="1">
			<thead>
				<tr>
					<th colspan="1"><a href="formulario.php">Nuevo</a></th>
					<th colspan="5">Lista de Empleados</th>
				</tr>
			</thead>

			<tbody>
				<tr>
					<td>Id</td>
					<td>Nombre</td>
                    <td>Apellidos</td>
					<td>Direccion</td>
					<td>Telefeno</td>
                    <td>Profesion</td>
                    <td>Cod_cargo</td>
                    <td>Estado_civil</td>
                    <td>Cod_area</td>
                    <td>Salario</td>
					<td>Correo</td>
                    <td>Ciudad</td>
                    <td>Cod_Historia</td>
					<td colspan="2">Operaciones</td>
				      </tr>


										       <?php
												include("Conexion.php");

												$query="SELECT * FROM empleados";
												$resultado=$conexion->query($query);
												while($row=$resultado->fetch_assoc()){
													?>
													<tr>
														<td><?php echo $row['id']; ?></td>
														<td><?php echo $row['Nombre']; ?></td>
														<td><?php echo $row['Apellidos']; ?></td>
														<td><?php echo $row['Direccion']; ?></td>
														<td><?php echo $row['Telefono']; ?></td>
                                                        <td><?php echo $row['Profesion']; ?></td>
                                                        <td><?php echo $row['Cod_cargo']; ?></td>
														<td><?php echo $row['Cod_estado_civil']; ?></td>
														<td><?php echo $row['Cod_area']; ?></td>
														<td><?php echo $row['Salario']; ?></td>
														<td><?php echo $row['Correo']; ?></td>
                                                        <td><?php echo $row['Ciudad']; ?></td>
                                                        <td><?php echo $row['Cod_historia']; ?></td>
                
                                                    
														<td><a href="modificar.php?Id=<?php echo $row['id']; ?>">Modificar</a></td>
														<td><a href="eliminar.php?Id=<?php echo $row['id']; ?>">Eliminar</a></td>
													</tr>
													<?php
												}
												?>

											</tbody>
										</table>
									</center>
								</body>
								</html>