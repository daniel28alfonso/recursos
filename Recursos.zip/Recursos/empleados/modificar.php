<html>
<head>
<meta charset="UTF-8" />
	<title></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>Parcial 1</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../../Vista/estilos.css">
	<title>Modificar</title>

</head>
<body>
	<center>
<div id="contenido">
		<?php
		include("Conexion.php");

		$id=$_REQUEST['Id'];

		$query="SELECT * FROM aspirante WHERE Id='$id'";
		$resultado=$conexion->query($query);
		$row=$resultado->fetch_assoc();

?>
<h1> Modificar datos del registros de usarios </h1>
<form action="Operacion_modificar.php?Id=<?php echo $row['Id']; ?>" method="POST">

	</br></br>
	<input type="text" REQUIRED name="Nombre" placeholder="Nombre"value="<?php echo $row['Nombre']; ?>" /> </br></br>
	<input type="text" REQUIRED name="Apellido" placeholder="Apellido"value="<?php echo $row['Apellido']; ?>" /> </br></br>
	<input type="text" REQUIRED name="Edad" placeholder="Edad"value="<?php echo $row['Edad']; ?>" /> </br></br>
<input type="text" REQUIRED name="Direccion" placeholder="Direccion"value="<?php echo $row['Direccion']; ?>" /> </br></br>
<input type="text" REQUIRED name="Telefono" placeholder="Telefono"value="<?php echo $row['Telefono']; ?>" /> </br></br>
<input type="text" REQUIRED name="Profesion" placeholder="Profesion"value="<?php echo $row['Profesion']; ?>" /> </br></br>
<input type="text" REQUIRED name="cargo" placeholder="cargo"value="<?php echo $row['Cargo']; ?>" /> </br></br>
<input type="text" REQUIRED name="Correo" placeholder="Correo"value="<?php echo $row['Correo']; ?>" /> </br></br>
<input type="text" REQUIRED name="Ciudad" placeholder="Ciudad"value="<?php echo $row['Ciudad']; ?>" /> </br></br>
<input type="text" REQUIRED name="Cod_estado_civil" placeholder="Cod_estado_civil"value="<?php echo $row['Cod_estado_civil']; ?>" /> </br></br>
<input type="text" REQUIRED name="Cod_contratado" placeholder="Cod_contratado"value="<?php echo $row['Cod_contratado']; ?>" /> </br></br>
<input type="text" REQUIRED name="Cod_historia" placeholder="Cod_historia"value="<?php echo $row['Cod_historia']; ?>" /> </br></br>
<input type="text" REQUIRED name="Cod_entrevista" placeholder="Cod_entrevista"value="<?php echo $row['Cod_entrevista']; ?>" /> </br></br>
	<input type="submit" value="Aceptar" />

</form>
</div>
</center>
</body>
</html>
