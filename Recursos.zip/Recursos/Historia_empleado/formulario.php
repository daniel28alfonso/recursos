<!DOCTYPE html>
<html>
<head>

   <title>Guardar</title>

</head>

<head>
	
<meta charset="UTF-8" />
	<title></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>PROYECTO</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	   <link rel="stylesheet" href="../estiloform.css">
   <title>Tabla</title>
</head>

<body>


     
 <div id="container">
  <h1>&bull; REGISTRO HISTORIAS EMPLEADOS&bull;</h1>
  <div class="underline">
  </div>

 
  <form action="Operacion_guardar.php" method="post" id="contact_form">

    <div class="name">
      <label for="name"></label>
      <input type="text" REQUIRED name="Cod_emp" placeholder="Cedula empleado..." value="" required>
    </div>
       <div class="submit">
      <input type="submit" value="REGISTRAR" id="form_button" />
    </div>
</form>
	
	<form action="../../Recursos/index.html" method="post" id="contact_form">

	      <div class="submit"><input type="submit" value="INICIO" id="form_button" />
               </div>
              </form>
     
      <form action="tabla.php" method="post" id="contact_form">

	      <div class="submit"><input type="submit" value="VER TABLA DE REGISTRO DE HISTORIAS" id="form_button" />
               </div>
              </form>
	
</body>
</html>

