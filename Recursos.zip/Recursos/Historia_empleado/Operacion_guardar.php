
<?php

include("Conexion.php");



$Cod_emp=$_POST['Cod_emp'];

$query="INSERT INTO historias_emp(Cod_emp) VALUES('$Cod_emp')";

$resultado= $conexion->query($query);

if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Insercion no exitosa";
}

?>