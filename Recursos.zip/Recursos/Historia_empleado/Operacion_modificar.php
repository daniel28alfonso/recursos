<?php

include("Conexion.php");
$id=$_REQUEST['Id'];
$Cod_emp=$_POST['Cod_emp'];

$query="UPDATE historias_emp SET Cod_emp='$Cod_emp' WHERE Id='$id'";

$resultado= $conexion->query($query);

if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Inserción no exitosa";
}

?>