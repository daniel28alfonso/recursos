var prom = function (numero1, numero2, numero3, name){
    
var numero1 = parseFloat(document.getElementById("cantP").value);
var numero2 = parseFloat(document.getElementById("cantT").value);
var numero3 = parseFloat(document.getElementById("cantC").value);




var resultado = ((numero1 + numero2 + numero3));


    if (resultado < 20) {
   alert("El valor es " + resultado);
    }else{
        
    }
       return resultado; 
};

var prom2 = function (numero4, numero5, numero6, name){
    
var numero4 = parseFloat(document.getElementById("valorP").value);
var numero5 = parseFloat(document.getElementById("valorT").value);
var numero6 = parseFloat(document.getElementById("valorC").value);




var resultados = ((numero4 + numero5 + numero6));


    if (resultados < 20) {
   alert("El valor es " + resultados);
    }else{
        
    }
       return resultados; 
};





