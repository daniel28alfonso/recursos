var prom2 = function (numero4, numero5, numero6, name){
    
var numero4= parseFloat(document.getElementById("valorP").value);
var numero5 = parseFloat(document.getElementById("valorT").value);
var numero6 = parseFloat(document.getElementById("valorC").value);




var resultado = ((numero4 + numero5 + numero6));
if (resultado < 20) {
   aler("El valor es " + resultado);
    }else {
       return resultado; 
    }


};
