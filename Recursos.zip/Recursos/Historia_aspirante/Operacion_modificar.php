<?php

include("Conexion.php");
$id=$_REQUEST['Id'];
$Cod_asp=$_POST['Cod_asp'];

$query="UPDATE historias_asp SET Cod_asp='$Cod_asp' WHERE Id='$id'";

$resultado= $conexion->query($query);

if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Inserción no exitosa";
}

?>