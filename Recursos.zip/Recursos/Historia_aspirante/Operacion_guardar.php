
<?php

include("Conexion.php");



$Cod_asp=$_POST['Cod_asp'];

$query="INSERT INTO historias_asp(Cod_asp) VALUES('$Cod_asp')";

$resultado= $conexion->query($query);

if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Insercion no exitosa";
}

?>