
<?php

include("Conexion.php");


$nombre=$_POST['Nombre'];
$cod_area=$_POST['Cod_area'];


$query="INSERT INTO cargos(Nombre,Cod_area) VALUES('$nombre','$cod_area')";

$resultado= $conexion->query($query);

if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Insercion no exitosa";
}

?>