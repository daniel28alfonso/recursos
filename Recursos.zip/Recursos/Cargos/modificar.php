<html>
<head>
<meta charset="UTF-8" />
	<title></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>Proyecto</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../../Vista/estilos.css">
	<title>Modificar</title>

</head>
<body>
	<center>
<div id="contenido">
		<?php
		include("Conexion.php");

		$id=$_REQUEST['Id'];

		$query="SELECT * FROM cargos WHERE Id='$id'";
		$resultado=$conexion->query($query);
		$row=$resultado->fetch_assoc();

?>
<h1> Modificar datos de los cargos </h1>
<form action="Operacion_modificar.php?Id=<?php echo $row['Id']; ?>" method="POST">

	</br></br>
	<input type="text" REQUIRED name="Nombre" placeholder="Nombre"value="<?php echo $row['Nombre']; ?>" /> </br></br>
	<input type="text" REQUIRED name="Cod_area" placeholder="Cod_area"value="<?php echo $row['Cod_area']; ?>" /> </br></br>

	<input type="submit" value="Aceptar" />

</form>
</div>
</center>
</body>
</html>
