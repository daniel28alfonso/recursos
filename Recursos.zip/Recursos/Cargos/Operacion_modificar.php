<?php

include("Conexion.php");

$id=$_REQUEST['Id'];
$nombre=$_POST['Nombre'];
$cod_area=$_POST['Cod_area'];

$query="UPDATE cargos SET Nombre='$nombre', Cod_area='$cod_area' WHERE Id='$id'";

$resultado= $conexion->query($query);

if($resultado){
	header("Location: tabla.php");
}

else{
	echo "Inserción no exitosa";
}

?>