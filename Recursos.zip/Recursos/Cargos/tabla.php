<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8" />
	<title></title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="estilotablaprob.css">
	<title>Tabla</title>


</head>



<header>
<center>
	<nav class="menu">
		
		<ul>
			<a href="../../Recursos/index.html">INICIO</a>
			<a href="../Cargos/formulario.php">VOLVER</a>
			
		</ul> 
	</ul>
</nav>
</center>
</header>



<body>

    <center></br></br></br>
		<table bgcolor="DF7401" border="1">
			<thead>
				<tr>
					<th colspan="1"><a href="formulario.php">Nuevo</a></th>
					<th colspan="5">Lista de Cargos</th>
				</tr>
			</thead>

			<tbody>
				<tr>
					<td>Id</td>
					<td>Nombre</td>
					<td>Cod_area</td>
					<td colspan="2">Operaciones</td>
				      </tr>


										       <?php
												include("Conexion.php");

												$query="SELECT * FROM cargos";
												$resultado=$conexion->query($query);
												while($row=$resultado->fetch_assoc()){
													?>
													<tr>
														<td><?php echo $row['Id']; ?></td>
														<td><?php echo $row['Nombre']; ?></td>
														<td><?php echo $row['Cod_area']; ?></td>
														<td><a href="modificar.php?Id=<?php echo $row['Id']; ?>">Modificar</a></td>
														<td><a href="eliminar.php?Id=<?php echo $row['Id']; ?>">Eliminar</a></td>
													</tr>
													<?php
												}
												?>

											</tbody>
										</table>
									</center>
								</body>
								</html>